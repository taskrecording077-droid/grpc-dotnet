using Grpc.Core;

namespace grpc.Services;

public class GreeterService(ILogger<GreeterService> logger) : Greeter.GreeterBase
{
    public override Task<HelloReply> SayHello(HelloRequest request, ServerCallContext context)
    {
        logger.LogInformation("SayHello called for {Name}", request.Name);

        return Task.FromResult(new HelloReply
        {
            Message = $"Hello {request.Name}!"
        });
    }

    public override Task<ServerInfoReply> GetServerInfo(ServerInfoRequest request, ServerCallContext context)
    {
        logger.LogInformation("GetServerInfo called by {ClientName}", request.ClientName);

        return Task.FromResult(new ServerInfoReply
        {
            Status = "ok",
            ServerName = "grpc-server",
            Message = $"Hello {request.ClientName}, the server is running successfully."
        });
    }
}
